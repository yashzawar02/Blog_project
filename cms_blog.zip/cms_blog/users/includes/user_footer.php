</div>
<footer class="container-fluid bg-4 text-center pull buttom">
    <p>Bootstrap Theme Made By <a href="../index.php">Bootstrap</a></p>
</footer>
<!-- jQuery -->
<script src="js/jquery.js"></script>
<!-- Scripts -->
<script src="js/scripts.js"></script>
<!-- Bootstrap Core JavaScript -->
<script src="js/bootstrap.min.js"></script>
</body>

</html>
