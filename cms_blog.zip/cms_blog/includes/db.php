<?php
ob_start();

$db['db_host'] = "localhost";
$db['db_user'] = "id11087921_root";
$db['db_pass'] = "root123";
$db['db_name'] = "id11087921_mydb";

foreach($db as $key => $value){
    define(strtoupper($key),$value);
}

$connection = mysqli_connect(DB_HOST,DB_USER,DB_PASS,DB_NAME);

?>
