	<div class="well">
		<div class='panel text-center'>
			<p>Social Networks</p>
			<a href='http://www.instagram.com/the_yash_zawar'><span><i class='fa fa-fw fa-instagram-square'></i></span></a> | <a href='http://twitter.com/YashZawar3'><span><i class='fa fa-fw fa-twitter-square'></i></span></a> |  <a href='http://facebook.com/Yash Zawar'><span><i class='fa fa-fw fa-facebook-square'></i></span></a> 

		</div>
	</div>
