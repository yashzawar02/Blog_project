<!-- jQuery -->
<center>
<footer>
<div class="w3-center w3-small w3-opacity">
A simple Blog project.
<a href="#">Copyright 2019 </a>  All Rights Reserved.<br>
</div>
</center><br>

<script src="js/jquery.js"></script>
<!-- Scripts -->
<script src="js/scripts.js"></script>
<!-- Bootstrap Core JavaScript -->
<script src="js/bootstrap.min.js"></script>

</body>

</html>
